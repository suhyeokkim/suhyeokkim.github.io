﻿using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ExampleBehaviour : MonoBehaviour
{
    public class SceneLoadData
    {
        public Scene scene;
        public LoadSceneMode mode;
        public bool willUnload;

        public SceneLoadData(Scene scene, LoadSceneMode mode)
        {
            this.scene = scene;
            this.mode = mode;
            willUnload = false;
        }
    }

    List<SceneLoadData> loadSceneList;
    private bool isAlreadyExist = false;

    void Awake()
    {
        isAlreadyExist = FindObjectOfType<ExampleBehaviour>() != this;

        loadSceneList = new List<SceneLoadData>();

        SceneManager.sceneLoaded += OnSceneLoad;
        SceneManager.sceneUnloaded += OnSceneUnload;
    }

    void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoad;
        SceneManager.sceneUnloaded -= OnSceneUnload;
    }

    public void OnSceneLoad(Scene nextScene, LoadSceneMode mode)
    {
        loadSceneList.Add(new SceneLoadData(nextScene, mode));
    }

    public void OnSceneUnload(Scene unloadedScene)
    {
        int index = loadSceneList.FindIndex((data) => unloadedScene.Equals(data.scene));

        if (index >= 0)
            loadSceneList.RemoveAt(index);

        isAlreadyExist = FindObjectOfType<ExampleBehaviour>() != this;
    }

    void OnGUI()
    {
        if (isAlreadyExist) return;
        
        GUILayout.Label("Current loaded scenes");

        loadSceneList.ForEach(
                (sceneData) =>
                {
                    GUILayout.Label(string.Format("{0} : {1}", sceneData.scene.name, sceneData.mode));

                    GUILayout.BeginHorizontal();

                    if (GUILayout.Button("Add"))
                    {
                        SceneManager.LoadScene(sceneData.scene.name, LoadSceneMode.Additive);
                    }

                    if (GUILayout.Button("Change"))
                    {
                        SceneManager.LoadScene(sceneData.scene.name, LoadSceneMode.Single);
                    }

                    if (GUILayout.Button("Unload"))
                    {
                        if (!sceneData.willUnload)
                        {
                            sceneData.willUnload = true;
                            SceneManager.UnloadSceneAsync(sceneData.scene);
                        }
                    }

                    GUILayout.EndHorizontal();

                    GUILayout.Space(10);
                }
            );

        GUILayout.Space(20);

        GUILayout.Label("Built in scenes");

        for (int i = 0; i < SceneManager.sceneCountInBuildSettings; i++)
        {
            Scene scene = SceneManager.GetSceneByBuildIndex(i);

            GUILayout.BeginHorizontal();

            GUILayout.Label(scene.path);

            if (GUILayout.Button("Add"))
            {
                SceneManager.LoadScene(i, LoadSceneMode.Additive);
            }

            if (GUILayout.Button("Change"))
            {
                SceneManager.LoadScene(i, LoadSceneMode.Single);
            }

            if (GUILayout.Button("Unload"))
            {
                if(scene.IsValid())
                {
                    SceneManager.UnloadSceneAsync(scene);
                }
            }

            GUILayout.EndHorizontal();

            GUILayout.Space(10);
        }
    }
}
