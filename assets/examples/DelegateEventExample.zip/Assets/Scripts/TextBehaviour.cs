﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextBehaviour : MonoBehaviour
{
    [SerializeField]
    private TimeTickBehaviour behaviour;

    private UnityEngine.UI.Text[] textArray;

    void Awake()
    {
        textArray = FindObjectsOfType<UnityEngine.UI.Text>();

        behaviour.oneSecondTick += (tick) => { textArray[0].text = tick.ToString(); };
        behaviour.tenSecondTick += (tick) => { textArray[1].text = tick.ToString(); };
        behaviour.twentySecondTick.AddListener((tick) => { textArray[2].text = tick.ToString(); });
    }
}
