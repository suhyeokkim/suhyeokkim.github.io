﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public delegate void TimeTickDelgate(int tickCount);

[System.Serializable]
public class TwentySecondTickEvent : UnityEvent<int> { }

public class TimeTickBehaviour : MonoBehaviour
{
    public TimeTickDelgate oneSecondTick;
    public int oneSecondCount;

    public event TimeTickDelgate tenSecondTick;
    public int tenSecondCount;

    public TwentySecondTickEvent twentySecondTick;
    public int twentySecondTickCount;

    void Awake()
    {
        oneSecondCount = 0;
        tenSecondCount = 0;
        twentySecondTickCount = 0;
        
        Invoke("OnSecond", 1f);
        Invoke("OnTenSeconds", 10f);
        Invoke("OnTwentySeconds", 20f);
    }

    void OnSecond()
    {
        oneSecondCount++;

        if (oneSecondTick != null) oneSecondTick.Invoke(oneSecondCount);

        Invoke("OnSecond", 1f);
    }
    void OnTenSeconds()
    {
        tenSecondCount++;

        if (tenSecondTick != null) tenSecondTick.Invoke(tenSecondCount);

        Invoke("OnTenSeconds", 10f);
    }
    void OnTwentySeconds()
    {
        twentySecondTickCount++;
        twentySecondTick.Invoke(twentySecondTickCount);

        Invoke("OnTwentySeconds", 20f);
    }
}
